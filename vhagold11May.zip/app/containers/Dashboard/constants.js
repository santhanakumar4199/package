/*
 *
 * Dashboard constants
 *
 */

export const DEFAULT_ACTION = 'app/Dashboard/DEFAULT_ACTION';
