/*
 *
 * Dashboard
 *
 */

import React, { PropTypes } from 'react';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';
import { FormattedMessage } from 'react-intl';
import { createStructuredSelector } from 'reselect';
import makeSelectDashboard from './selectors';
import messages from './messages';
import { take, call, put, select, cancel, takeLatest } from 'redux-saga/effects';
import { defaultAction ,mobileNumber } from './actions';
import { makeSelectLogin,makeSelectLocationState } from 'containers/Login/selectors';
import defaultSagaD from './selectors';
import {List,ListItem,StyledBackground,Label,Input,Badge,Block,Button,Caption,Heading,HorizontalRule,StyledAlert,StyledSections,TextLinks} from 'components';
import BgImage from './BgImage1.jpg';

import Accordian from 'components/molecules/Accordian';
export class Dashboard extends React.PureComponent { // eslint-disable-line react/prefer-stateless-function

   constructor(props) {
    super(props);
    this.props={
      test:''
    }
   // this.handlers = createHandlers(this.props.dispatch);
  }

  componentWillMount(){
    const mobileNumber = defaultSagaD();

    const test = this.props.handleSubmit();
    console.log("getuserCheck5ntest",test);
  }

  render() {

    const panCen = {margin: "auto",width:"560px","background-color":"white","box-shadow": "1px 1px 7px 4px #d6d6d6",height: "360px"}
    const alginChart = {"margin-left":"100px"}
    const lblfont = {"font-size":"24px"}
    const divback = {"background-color": "#eee","margin-top": "8px","border-radius":"6px"}
    const divbackunder = {"background-color": "#eee","margin-top": "8px","border-radius":"6px","margin-top":"30%"}
    const AccordianContainer = ({accorChange,props}) => <Accordian accorChange {...props}/>
    const comment = {
                      arrow: '',
                      text: 'I hope you enjoy learning React!',
                      author: {
                        name: 'Hello Kitty',
                        avatarUrl: 'http://placekitten.com/g/64/64'
                      }
                    };

    return (
      <Block>
      
       //components render starts

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Accordian</Heading>
          <Block>
        
            To be added

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Alert</Heading>
          
          <Block>
            <StyledAlert alertType="valert" />
          </Block>

          <Block>
            <StyledAlert alertType="myalert" />
          </Block>

          <Block>
            <StyledAlert alertType="alertone" />
          </Block>

          <Block>
            <StyledAlert alertType="alerttwo" />
          </Block>

        </Block> 

         <Block style={{padding: "10em"}}>
          <Heading level ={2}>Background</Heading>
          <Block>
        
            <StyledBackground BgImageURL={BgImage} bgText="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse pretium, massa quis mollis dapibus, ipsum libero vulputate turpis, et cursus risus turpis ac dolor. Integer fringilla urna at massa consequat, ac pellentesque leo consectetur. Nulla erat metus, mollis non velit laoreet, venenatis commodo ipsum." />

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Breadcrumbs</Heading>
          <Block>
        
            <StyledSections sectionType="bread">
             <List ordered={true} >
             <TextLinks linkType="linkbody" children="Home" href="www.google.com"></TextLinks>
                     
               </List>
               <List ordered={true} >
                  >
                     
               </List>
               <List ordered= {true} >
                <TextLinks   children=" Shop"></TextLinks>
               </List>
             
            
             </StyledSections>

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Bubble</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Bundles</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Button</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Carousel</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Chevron</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Colors</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Device</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Dialogs</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Equal rows</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Forms</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Grids</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Headings</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Hello</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Hello Icons</Heading>
          <Block>
        
            

          </Block>
        </Block> 

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Lists</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Media</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Page</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Rating</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Sections</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Simple Tabs</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Slider</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Springs</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Tables</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Text links</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Tiles</Heading>
          <Block>
        
            

          </Block>
        </Block>

        <Block style={{padding: "10em"}}>
          <Heading level ={2}>Trumps</Heading>
          <Block>
        
            

          </Block>
        </Block>
      </Block>
    );
  }
}

Dashboard.propTypes = {
  dispatch: PropTypes.func.isRequired,
  handleSubmit:PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  Dashboard: makeSelectDashboard(),

});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    handleSubmit: (evt) => {
     const  test =  dispatch(defaultAction());
     console.log("testtesttest",test);
    },

  };
}

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
