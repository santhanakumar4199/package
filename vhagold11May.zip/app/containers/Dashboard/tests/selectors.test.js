// import { fromJS } from 'immutable';
// import { makeSelectDashboardDomain } from '../selectors';

// const selector = makeSelectDashboardDomain();

describe('makeSelectDashboardDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
