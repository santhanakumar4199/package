/*
 *
 * Login constants
 *
 */

export const CHANGE_MOBILENUMBER = 'boilerplate/Login/CHANGE_MOBILENUMBER';
export const CHECK_USER = 'boilerplate/Login/CHECK_USER';
export const LOAD_REPOS_SUCCESS = 'boilerplate/App/LOAD_REPOS_SUCCESS';
export const LOAD_REPOS_ERROR = 'boilerplate/App/LOAD_REPOS_ERROR';
