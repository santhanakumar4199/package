// import { fromJS } from 'immutable';
// import { makeSelectLoginDomain } from '../selectors';

// const selector = makeSelectLoginDomain();

describe('makeSelectLoginDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
