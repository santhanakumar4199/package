/**
*
* GenericPage
*
*/

import React from 'react'

const GenericPage = () => {
  return (
    <div>Generic Page</div>
  )
}

export default GenericPage

