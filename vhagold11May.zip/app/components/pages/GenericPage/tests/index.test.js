// import React from 'react';
// import { shallow } from 'enzyme';

// import GenericPage from '../index';

describe('<GenericPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
