/*
 * Demosections Messages
 *
 * This contains all the text for the Demosections component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Demosections.header',
    defaultMessage: 'This is the Demosections component !',
  },
});
