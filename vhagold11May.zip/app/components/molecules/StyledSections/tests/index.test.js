// import React from 'react';
// import { shallow } from 'enzyme';

// import Demosections from '../index';

describe('<StyledSections />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
