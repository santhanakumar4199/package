// import React from 'react';
// import { shallow } from 'enzyme';

// import Chevrons from '../index';

describe('<Chevrons />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
