// import React from 'react';
// import { shallow } from 'enzyme';

// import Demotiles from '../index';

describe('<StyledTiles />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
