/*
 * Demotiles Messages
 *
 * This contains all the text for the Demotiles component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Demotiles.header',
    defaultMessage: 'This is the Demotiles component !',
  },
});
