// import React from 'react';
// import { shallow } from 'enzyme';

// import Myalert from '../index';

describe('<StyledAlert />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
