/*
 * Myalert Messages
 *
 * This contains all the text for the Myalert component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Myalert.header',
    defaultMessage: 'This is the Myalert component !',
  },
});
