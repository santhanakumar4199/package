// import React from 'react';
// import { shallow } from 'enzyme';

// import Table from '../index';

describe('<Table />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
