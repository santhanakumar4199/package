// import React from 'react';
// import { shallow } from 'enzyme';

// import Post from '../index';

describe('<Post />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
