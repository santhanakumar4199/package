// import React from 'react';
// import { shallow } from 'enzyme';

// import Device from '../index';

describe('<Device />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
