// import React from 'react';
// import { shallow } from 'enzyme';

// import Icon from '../index';

describe('<StyledIcon />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
