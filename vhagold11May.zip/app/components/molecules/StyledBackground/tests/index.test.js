// import React from 'react';
// import { shallow } from 'enzyme';

// import StyledBackground from '../index';

describe('<StyledBackground />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
