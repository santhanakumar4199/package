// import React from 'react';
// import { shallow } from 'enzyme';

// import Page from '../index';

describe('<Page />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
