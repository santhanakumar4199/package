/*
 * Accordian Messages
 *
 * This contains all the text for the Accordian component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.Accordian.header',
    defaultMessage: 'This is the Accordian component !',
  },
});
