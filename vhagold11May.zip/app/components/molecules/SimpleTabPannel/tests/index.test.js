// import React from 'react';
// import { shallow } from 'enzyme';

// import TabPannel from '../index';

describe('<TabPannel />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
