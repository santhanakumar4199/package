// import React from 'react';
// import { shallow } from 'enzyme';

// import Spring from '../index';

describe('<Spring />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
