// import React from 'react';
// import { shallow } from 'enzyme';

// import TextLinks from '../index';

describe('<TextLinks />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
