// import React from 'react';
// import { shallow } from 'enzyme';

// import List from '../index';

describe('<List />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
