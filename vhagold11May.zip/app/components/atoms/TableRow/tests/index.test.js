// import React from 'react';
// import { shallow } from 'enzyme';

// import TableRow from '../index';

describe('<TableRow />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
