/**
*
* LogoImage
*
*/

import React from 'react'

import logo from './logo.svg'

const LogoImage = props => <img alt="Logo" {...props} src={logo} />

export default LogoImage

