// import React from 'react';
// import { shallow } from 'enzyme';

// import Img from '../index';

describe('<Img />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
