// import React from 'react';
// import { shallow } from 'enzyme';

// import Hero from '../index';

describe('<Hero />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
