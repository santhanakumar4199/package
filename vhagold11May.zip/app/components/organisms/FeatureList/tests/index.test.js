// import React from 'react';
// import { shallow } from 'enzyme';

// import FeatureList from '../index';

describe('<FeatureList />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
